"""
Given a string, you need to reverse the order of characters in each word
within a sentence while still preserving whitespace and initial word order.

Example 1:
    Input: "Where's my cake?"
    Output: "s'erehW ym ?ekac"
Example 2:
    Input: "I'll never forget that cake"
    Output: "ll'I reven tegrof taht ekac"

Note: In the string, each word is separated by a single space and there
will not be any extra space in the string.
"""

def reverseWords(words):
    # Your code here
    pass