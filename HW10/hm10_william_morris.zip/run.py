def reverseWords(words):
    return " ".join([i[::-1] for i in words.split()])